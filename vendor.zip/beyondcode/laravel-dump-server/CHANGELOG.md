# Changelog

All notable changes to `laravel-dump-server` will be documented in this file

## 1.0.0 - 2018-07-09

- initial release
